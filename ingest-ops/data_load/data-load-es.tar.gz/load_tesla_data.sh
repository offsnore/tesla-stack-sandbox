for ((i=0; i<40; i++)); do ./tesla-send-json-files.sh & done
