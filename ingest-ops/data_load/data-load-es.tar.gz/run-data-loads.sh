cd /data/tesla
./data-load-wake_up.sh  &
./data-load-charge-state.sh &
./data-load-climate-state.sh &
./data-load-drive-state.sh  &
./data-load-gui-settings.sh &
./data-load-vehicle-state.sh &
